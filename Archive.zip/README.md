# Reviews_Polancich
This will be the Reviews Module

Structure is as Follows

          - APP.jsx 
            - SummaryMain
              - Customer Rating
              - Customer Rating Visualizer
              - Recommendation
          
            - PhotoHeadersList
              - Photos
          
            - ReviewsList
              - Review
                - ReviewsNameArea
                - ReviewCommentArea
            
            - Footer
        
