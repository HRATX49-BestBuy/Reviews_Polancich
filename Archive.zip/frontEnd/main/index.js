import React from 'react';
import ReactDOM from 'react-dom';
import App from './Main.jsx'

ReactDOM.render(
<App />, 
document.getElementById('Review')
);


